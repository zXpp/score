# encoding: utf-8

datadir='/media/winky/TOOLS/test_12_17/'
mfcc='test.mfcc.normal'
bn='test.bn'
combine='test.combine'
testlist=['test1','test2','test3','test4','test6','test7']
feadir=['test_full','test_sub','test_inter','test_null']

for test in testlist:
    for fea in feadir:
        feafile=datadir+test+'/'+'test_full'+'/'+mfcc
	feafile_=datadir+test+'/'+fea+'/'+bn
        print feafile_
        outfea=datadir+test+'/'+fea+'/'+combine+'.normal'
        mfccfile=open(feafile,'r')
	bnfile=open(feafile_,'r')
        outfile=open(outfea,'w')
	while True:
	    mfccline=mfccfile.readline().lstrip().rstrip()
            bnline=bnfile.readline().lstrip().rstrip()
	    if not mfccline and not mfccline:
		break
	    else:
		outfile.write(mfccline)
		outfile.write(' ')
		outfile.write(bnline)
		outfile.write('\n')
	mfccfile.close()
	bnfile.close()
	outfile.close()
