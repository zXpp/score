#!/usr/bin/python
"""
this script is tp change the para to the next element in the $params in runscore.sh ,overwrite the old config file and set the current param
"""
import os,sys,re
if len(sys.argv)!=3:
    print 'please input beta which to be changed!'

changebeta=sys.argv[2]
print changebeta
readfilepath=sys.argv[1]
readfile=open(readfilepath,'r')

try:
    lines=readfile.readlines()#read config all lines
    if not lines:
        raise Exception
    else:
        flen = len(lines)-1
        for i in range(flen):
            if lines[i].find('MODEL_SEL_PARAM=')!=-1:
                matchtemp=re.match(r'(\w+)=(.*)',lines[i])
                beta=matchtemp.group(2)
                print "current para : ",beta," will be replaced by newer : ",str(changebeta)
                lines[i]=lines[i].replace(beta,str(changebeta))
                print lines[i]
            else:
                continue
    readfile.close()
    open(readfilepath,'w').writelines(lines)##overwirte/rewrite the config to the newest
    readfile.close()
except Exception as e:
    print e

