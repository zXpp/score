#!/usr/bin/python
#translate stm file to mlf file

import os,sys
import itertools

if len(sys.argv)!=4:
    print "------------------------------------------------"
    print "\nUSAGE: python  script.py refRTTMFile sysRTTMFile outputfile"
    print "\n---------- Error!! ------------------------------"
    sys.exit()

reffile=sys.argv[1]
sysfile=sys.argv[2]
outputfile=sys.argv[3]

refstream=open(reffile,'r')
sysstream=open(sysfile,'r')
outputstream=open(outputfile,'w')

audiotype=set()
outtype=set()
matriclist=[]
reflist=[]
syslist=[]

matric=[]

while True:
    refline=refstream.readline()
    sysline=sysstream.readline()
    if not refline or not sysline:
        break
    else:
        systemp=sysline.split(' ')
        reftemp=refline.split(' ')
        sysid=systemp[-2] 
        refid=reftemp[-2]
        reflist.append(refid)
        syslist.append(sysid)
        audiotype.add(refid)
        outtype.add(sysid)
        matriclist.append('{0}_{1}'.format(refid,sysid))
refstream.close()
sysstream.close()

outtypenum=len(outtype)
totlen=len(reflist)
for numid in range(1,outtypenum+1):
    outputstream.write('\taudio_{}'.format(numid))
outputstream.write('\n')
for iterm in audiotype:
    outputstream.write('{}\t'.format(iterm))
    itermlen=reflist.count(iterm)
    matrictemp=[]
    for outiterm in range(1,outtypenum+1):
        matriciterm=iterm+'_'+'spkr'+'_'+str(outiterm)
        audionum=matriclist.count(matriciterm)
        matrictemp.append(audionum)
	rate=float(audionum)/float(itermlen)
        outputstream.write(str(round(rate,4)*100))
        #outputstream.write(str(audionum))	
        outputstream.write('\t')
    outputstream.write('\n')
    matric.append(matrictemp) 

#compute asp
cc=[]
for rowlist in matric:
    num=len(rowlist)
    ni=sum(rowlist)
    pii=0
    #import ipdb;ipdb.set_trace()
    for nij in rowlist:  
        tmppii=float(nij*nij)/float(ni)
        pii=pii+tmppii
    piini=pii
    cc.append(piini)
asp=sum(cc)/float(totlen)
print 'asp:',asp
outputstream.write('asp:')
outputstream.write(str(asp))
outputstream.write('\n')
dd=[]
transmatric=map(list,zip(*matric))
for rowlist in transmatric:
    num=len(rowlist)
    ni=sum(rowlist)
    pii=0
    for nij in rowlist:  
        tmppii=float(nij*nij)/float(ni)
        pii=pii+tmppii
    piini=pii
    dd.append(piini)
acp=sum(dd)/float(totlen)
print 'acp:',acp
outputstream.write('acp:')
outputstream.write(str(acp))
outputstream.write('\n')
f=2*asp*acp/(asp+acp)
print 'f:',f
outputstream.write('f:')
outputstream.write(str(f))
outputstream.write('\n')
outputstream.close()

