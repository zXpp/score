#!/usr/bin/python

import os,sys,re

if len(sys.argv)!=2:
    print 'please input script which to be changed!'

readfilepath=sys.argv[1]

readfile=open(readfilepath,'r')
#import ipdb;ipdb.set_trace()
try:
    lines=readfile.readlines()
    if not lines:
        raise Exception
    else:
        flen = len(lines)-1
        for i in range(flen):  
            if lines[i].find('#bin/aibfeat')!=-1:
                beta='#bin/aibfeat'
		changefeadir='bin/aibfeat'
                print beta,str(changefeadir)
                lines[i]=lines[i].replace(beta,str(changefeadir))
            elif lines[i].find('bin/aibfeat')!=-1:
		break
            else:
                continue
    readfile.close()
    open(readfilepath,'w').writelines(lines)
    readfile.close()
except Exception as e:
    print e
