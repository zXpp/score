#!/usr/bin/python
import os,sys,re

if len(sys.argv)!=3:
    print 'please input beta which to be changed!'

changefeadir=sys.argv[1]
print changefeadir
readfilepath=sys.argv[2]

readfile=open(readfilepath,'r')

try:
    lines=readfile.readlines()
    if not lines:
        raise Exception
    else:
        flen = len(lines)-1
        for i in range(flen):  
            if lines[i].find('for testdir in ')!=-1:
                matchtemp=re.match(r'for testdir in (\w+)\n',lines[i])
                beta=matchtemp.group(1)
                print beta,str(changefeadir)
                lines[i]=lines[i].replace(beta,str(changefeadir))
                print lines[i]
            else:
                continue
    readfile.close()
    open(readfilepath,'w').writelines(lines)
    readfile.close()
except Exception as e:
    print e

