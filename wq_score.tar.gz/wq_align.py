#!/usr/bin/python
#align stm file

import os,sys,re
if len(sys.argv)!=3:
	print "------------------------------------------------"
	print "\nUSAGE: python  script.py CTMFile STMFile"
	print "\n---------- Error!! --------------------------------------"
	sys.exit()

ctm=sys.argv[1]
stm=sys.argv[2]

ctmfile=open(ctm,'r')
stmfile=open(stm,'w')

dataid=""
aligntime=0
dataname=""
idlist=[]
timelist=[]
datanamelist=[]
t1=0
t2=0

while True:
	line=ctmfile.readline()
	if not line:
		break
	else:
		temp=line.split(' ')
		id = temp[0]
		if id == dataid:
			t1=temp[2]
			t2=temp[3]
			continue
		idlist.append(id)
		aligntime=float(t1)+float(t2)
		timelist.append(str(aligntime))
		t1=temp[2]
		t2=temp[3]
		dataid=id
		matchtemp=re.match(r'(\w+)_([a-z]+)(\d+)',dataid)
		dataname=matchtemp.group(2)
		datanamelist.append(dataname)
timelist.append(aligntime)
if dataid != idlist[len(idlist)-1]:
	idlist.append(dataid)
	datanamelist.append(dataname) 
ctmfile.close()
#import ipdb;ipdb.set_trace()
timelist=timelist[1:len(timelist)]
for i in range(len(timelist)):
	wrtline="{0} 1 fb 0.0 {1} <0,F> {2}\n".format(idlist[i],timelist[i],datanamelist[i])
	stmfile.write(wrtline)
stmfile.close()
