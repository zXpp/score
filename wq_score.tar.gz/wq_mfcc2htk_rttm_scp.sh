#!/bin/bash

gendir=/home/winky  #根目录
kaldidir=kaldi-trunk/egs/test_winky/s5  #kaldi例程路径
MATLAB="/usr/local/MATLAB/R2014b/bin/glnxa64/MATLAB -nojvm -nosplash"
datadir=test_4_20       #结果存放路径
testdirs="test1"        #测试数据编号,如果有多个，则可直接加在后面，用空格隔开，例“test1 test2 test3”
tardirs="test_dbn"  
ids="bn combine mfcc"
htk_path=score        #writehtk函数的存放路径
fp=0.016           # writehtk函数的参数，表示采样率

for testdir in $testdirs
do
  echo $testdir
  for tardir in $tardirs   
  do
    echo $tardir
    for id in $ids
    do
      echo $id
      txtfeadir=$gendir/$datadir/$testdir/$tardir
      htkfeadir=$gendir/$datadir/htk_fea/$testdir/$tardir
      mkdir -p $txtfeadir $htkfeadir
      python score/wq_bn2raw.py $gendir/$kaldidir/$testdir/$tardir/test/${id}.1.txt $txtfeadir/test.${id}
      $MATLAB -r "addpath('$gendir/$htk_path');d=load('$txtfeadir/test.${id}');writehtk('$htkfeadir/test.${id}',d,$fp,9); exit;";
    done
  done
  python score/wq_mfcc2scp.py $gendir/$kaldidir/$testdir/$tardir/test/mfcc.1.txt $gendir/$datadir/$testdir/test.scp
  python score/wq_mfcc2rttm.py $gendir/$kaldidir/$testdir/$tardir/test/mfcc.1.txt $gendir/$datadir/$testdir/test.ref.rttm
done



