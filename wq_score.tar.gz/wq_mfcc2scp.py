#!/usr/bin/python
#translate stm file to mlf file

import os,sys,re
if len(sys.argv)!=3:
    print "------------------------------------------------"
    print "\nUSAGE: python  script.py MFCCFile MLFFile "
    print "\n---------- Error!! --------------------------------------"
    sys.exit()

mfcc=sys.argv[1]
scp=sys.argv[2]
try:
    mfccfile=open(mfcc,'r')
    scpfile=open(scp,'w')
except IOError as ioerr:
    print("io error:{0}".format(ioerr))

index=0
startpoint=0
while True:
    mfccline=mfccfile.readline()
    if not mfccline:
        break
    else:
        if  mfccline.find('[')!=-1:
            startpoint=index+1
            continue
        else:
            index+=1
            if mfccline.find(']')!=-1:
                endpoint=index
                refline='chain_'+str(startpoint)+'_'+str(endpoint)+'=../data/chain.fea['+str(startpoint)+','+str(endpoint)+']'+'\n'
                scpfile.write(refline)
            else:
                continue
mfccfile.close()
scpfile.close()

