# encoding: utf-8

datadir='/media/winky/TOOLS/test_12_17/'
readfile='test.mfcc'
testlist=['test1','test2','test3','test4','test6','test7']
feadir=['test_full']

for test in testlist:
    for fea in feadir:
        feafile=datadir+test+'/'+fea+'/'+readfile
	print feafile
        outfea=datadir+test+'/'+fea+'/'+readfile+'.normal'
        featurefile=open(feafile,'r')
        outfile=open(outfea,'w')
        while True:
	        fileline=featurefile.readline().lstrip().rstrip()
	        if not fileline:
		        break
	        else:
		        featuredatas=fileline.split(' ')
                	featuredatas = map(float, featuredatas)
		        maxdata=max(featuredatas)
		        mindata=min(featuredatas)
		        fenmu=maxdata-mindata
		        for data in featuredatas:
		            normaldata=(data-mindata)/fenmu
		            outfile.write(str(normaldata))
		            outfile.write(' ')
		        outfile.write('\n')
        featurefile.close()
        outfile.close()
